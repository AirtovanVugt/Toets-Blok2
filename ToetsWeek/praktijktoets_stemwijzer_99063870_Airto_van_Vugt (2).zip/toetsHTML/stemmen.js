var container = document.getElementById("stemmen-container");

var vragen = ["Nederland moet terug naar de Gulden", "Er moet meer geld naar ontwikkelingshulp", "De overheid moet afslanken", "De AOW leeftijd moet terug naar 67 jaar", "Wietteelt moet worden gelegaliseerd", "We moeten minder geld aan het leger uitgeven", "Alle werkenden moeten minder loonbelasting betalen", "Wil je de natuur verbeteren", "Iedereen gelijke rechten"];
//                    vraag 0                                     vraag 2                                     vraag 3                           vraag 4                                vraag 5                              vraag 6                                       vraag 7                                                 vraag 8             vraag 9
var partijNamen = ["CDA", "CDA", "VVD", "VVD", "VVD", "pvdA", "pvdA", "pvdA", "D66", "D66"];
//                   0      1      2     3       4       5       6       7      8      9
var knopnamen = ["eens", "oneens", "volgende"];

var deH = document.createElement("h1");
deH.id = "vraag";
container.appendChild(deH);

var knopjesContainer = document.createElement("div")
knopjesContainer.id = "knoppenContainer";
container.appendChild(knopjesContainer);

for(i=0; i<=2; i++){
	var knoppen = document.createElement("button");
	knoppen.innerText = knopnamen[i];
	knoppen.id = "knop" + i;
	knoppenContainer.appendChild(knoppen);
}

var geklikt = 0;
var eensklik = 0;

	vraag.innerText = vragen[0];

	var eensknop = document.getElementById("knop0");
	var oneensknop = document.getElementById("knop1");
	var volgende = document.getElementById("knop2");

	volgende.style.display = "none";

eensknop.onclick = function(){
	if(volgende.style.display == "inline-block"){

	}
	else{
		var zeker = prompt("weet je zeker dat je dit wilt?");
		if(zeker == "ja"){
			eensklik++;
			volgende.style.display = "inline-block";
			next();
		}
		else{

		}		
	}
}

oneensknop.onclick = function(){
	if(volgende.style.display == "inline-block"){

	}
	else{
		var zeker = prompt("weet je zeker dat je dit wilt?");
		if(zeker == "ja"){
			volgende.style.display = "inline-block";
			next();
		}
		else{

		}
	}
}

function next(){
	geklikt++;
	if(geklikt == 9){
		volgende.innerText = "voltooien";
	}
	volgende.onclick = function(){
		if(geklikt == 9){
			uitslag();
		}
		else{
			vraag.innerText = vragen[geklikt];
			volgende.style.display = "none";
		}
	}
}

function uitslag(){
	vraag.innerText = "bedankt voor het stemmen";
	var uitslag = document.createElement("p");
	container.appendChild(uitslag);
	uitslag.innerText = "U heeft " + eensklik + " keer eens gestemd. De partij die het beste bij u voorkeur past is " + partijNamen[eensklik];
	eensknop.style.display = "none";
	oneensknop.style.display = "none";
	volgende.style.display = "none";
	vraag.style.display = "none";
}